[Jquery Highlight](https://github.com/ematsakov/highlight)
========

Jquery Highlight Plugin allows syntax highlighting of source code snippets in an html page.

Documentation
-----------
[Here](http://webcodingstudio.com/blog/jquery-syntax-highlight-plugin) you can find more info about Jquery Highlight Plugin.

Demos and Examples
-----------
+ http://demo.webcodingstudio.com/highlight/demo.html

Download
-----------
Clone the repo, `git clone git://github.com/ematsakov/highlight.git`, or [download the latest release](https://github.com/ematsakov/highlight/zipball/master).
