<?php 
session_start();
include_once('php-database-manipulation-files/db-connection.php');
include_once('php-database-manipulation-files/php_query_functions.php');
?>